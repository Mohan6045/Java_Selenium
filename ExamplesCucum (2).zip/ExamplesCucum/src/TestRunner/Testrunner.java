package TestRunner;

import cucumber.api.CucumberOptions;
import cucumber.api.testng.AbstractTestNGCucumberTests;

@CucumberOptions(features="FEATURES",glue="STEP_DEf")


public class Testrunner extends AbstractTestNGCucumberTests{
	
}