package STEP_DEF;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class testcumc {
	WebDriver dr;
	
	@Given("^browser launhed &  select programming$")
	public void browser_launhed_select_programming()  {
		System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
		 dr=new ChromeDriver();
		dr.get("http://examples.codecharge.com/store/Default.php");
	   
	}

	@When("^click search & verify title in next page$")
	public void click_search_verify_title_in_next_page()  {
	   System.out.println("mo");
	}

	@Then("^verify the name of second book$")
	public void verify_the_name_of_second_book()  {
		System.out.println("mo");
	}

	
	

}
