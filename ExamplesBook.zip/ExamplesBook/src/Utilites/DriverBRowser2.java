package Utilites;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class DriverBRowser2 {
	
	static WebDriver dr;
	
	public   static WebDriver Launch_browser(String BrowName,String URl)
	{
		switch(BrowName)
		{
		
		case "Chrome":
		System.setProperty("webdriver.chrome.driver","chromedriver.exe");
		dr=new ChromeDriver();
		case "FireFox":
			System.setProperty("webdriver.gecko.driver","geckodriver.exe");
			dr=new FirefoxDriver();
		
		}
		dr.get(URl);
		return dr;
	}

	
	
	
	

}
