package TestNgBOOk;

import org.testng.annotations.Test;

import Utilites.DriverBRowser2;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeClass;

public class NewTest214 extends DriverBRowser2 {

	WebDriver dr;
  @Test
  public void f() {
	  System.out.println("mohan");
	  
	  
  }
  @BeforeClass
  public void beforeClass1() {
	 
	dr=DriverBRowser2.Launch_browser("Chrome", "http://examples.codecharge.com/Store/Default.php");
	
	  
  }
}
