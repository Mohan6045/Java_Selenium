package pkg12;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;

public class NewTest213 {
  @Test
  public void f() {
	  
	  System.setProperty("webdriver.gecko.driver","geckodriver.exe");
	  WebDriver dr =new FirefoxDriver();
	  dr.get("https://github.com/mozilla/geckodriver/releases");
  }
}
