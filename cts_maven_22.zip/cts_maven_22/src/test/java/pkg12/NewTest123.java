package pkg12;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class NewTest123 {
  @Test
  public void f() {
	 
	  System.setProperty("webdriver.chrome.driver","chromedriver.exe");
	  WebDriver dr=new ChromeDriver();
	  dr.get("https://mvnrepository.com/artifact/org.testng/testng/7.0.0");
	  
  }
}
