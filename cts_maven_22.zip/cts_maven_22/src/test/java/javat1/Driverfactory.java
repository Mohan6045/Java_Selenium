package javat1;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Driverfactory {
	
	public static WebDriver launch_browser(String browser,String url)
	{
		
		
		WebDriver dr=null;
		switch(browser)
		{
		case "CHROME":
			System.setProperty("webdriver.chrome.driver","chromedriver.exe");
			dr=new ChromeDriver();
		break;
		case "FIREFOX":
			System.setProperty("webdriver.chrome.driver","chromedriver.exe");
			dr=new FirefoxDriver();
		break;
			
		}
		
		dr.get(url);
		
		
		return dr;
	}
	
	
	

}
