package testngbrowser;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import javat1.Driverfactory;

public class NewTest541 extends Driverfactory {
	
	WebDriver dr;
	
	String url="http://demowebshop.tricentis.com/";
  @Test
  public void f() {
	  dr=Driverfactory.launch_browser("CHROME", url);
	  
	  
	  
  }
}
