package TestNGFile;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import Utitity.DRIVEBrowser;
import pages12.page1select;
import pages12.page2verify;

public class ExamTEstNg extends DRIVEBrowser{
	
	WebDriver dr;
	String match2tile="SearchResults";
	String data2page="Perl and CGI for the World Wide Web";
  @BeforeClass
  public void launhBrowser() {
	  String matchtile="Online Bookstore";
	  dr=DRIVEBrowser.DBStart("CHROME", "http://examples.codecharge.com/store/Default.php");
	  String title= dr.getTitle();
	SoftAssert ss=new SoftAssert();
	ss.assertEquals(title,matchtile);
	ss.assertAll();
	   
  }
  @Test(priority=0)
  public void selct()
  {
	  page1select p1=new page1select(dr);
	  p1.selectprog();
  }
  @Test(priority=1)
  public void selct2()
  {
	  page2verify p2=new page2verify(dr);
	 String tiel=p2.getTitle();
	 SoftAssert ss1=new SoftAssert();
		ss1.assertEquals(tiel,match2tile);
		ss1.assertAll();
	// System.out.println(tiel);	 
  }
  @Test(priority=2)
  public void selct21()
  {
	  page2verify p2=new page2verify(dr);
	  String name2=p2.get2name();
	 SoftAssert ss1=new SoftAssert();
		ss1.assertEquals(name2,data2page);
		ss1.assertAll();
	 
	// System.out.println(name2);
	 
  }
  
  
}
