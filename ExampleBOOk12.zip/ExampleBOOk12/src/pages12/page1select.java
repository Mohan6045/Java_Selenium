package pages12;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

public class page1select {
	
	
	WebDriver dr;
	
	public page1select(WebDriver dr)
	{
		this.dr=dr;
	}
	//                /html/body/table[5]/tbody/tr/td/table[2]/tbody/tr[3]/td[2]/b/a
	
	public void selectprog()
	{
		WebElement we=dr.findElement(By.xpath("//select[@name='category_id']"));
		Select ss=new Select(we);
		ss.selectByVisibleText("Programming");
		dr.findElement(By.xpath("//input[@name='DoSearch']")).click();
	}
	
	

}
