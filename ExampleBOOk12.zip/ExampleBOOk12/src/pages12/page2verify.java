package pages12;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class page2verify {
	WebDriver dr;
	
	public page2verify(WebDriver dr)
	{
		this.dr=dr;
	}
	
	
	public String getTitle()
	{
		return dr.getTitle();
	}
	
	public String get2name()
	{
		return dr.findElement(By.xpath("/html/body/table[5]/tbody/tr/td/table[2]/tbody/tr[3]/td[2]/b/a")).getText();
	}
	
	

}
