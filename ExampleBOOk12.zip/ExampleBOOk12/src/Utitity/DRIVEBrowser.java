package Utitity;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class DRIVEBrowser {
	static WebDriver dr;
	public static WebDriver DBStart(String DBname,String URl)
	{
		
		switch(DBname)
		{
		case "CHROME":
			System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
			dr=new ChromeDriver();
			break;
		case "Firefox":
			System.setProperty("webdriver.gecko.driver", "geckodriver.exe");
			dr=new FirefoxDriver();
			break;
		}
		
		dr.get(URl);
		return dr;
	}
	

}
