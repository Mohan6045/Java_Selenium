package STEP_DEF;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.asserts.SoftAssert;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class TESTCUCUM {
	static WebDriver dr;
	 String matchtile="SearchResults";
	  String name2match="Perl and CGI for the World Wide Web";
	@Given("^browser launhed &  select programming$")
	public void browser_launhed_select_programming() throws Throwable {
	    
		System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
		dr=new ChromeDriver();
		dr.get("http://examples.codecharge.com/store/Default.php");
		WebElement we=dr.findElement(By.xpath("//select[@name='category_id']"));
		Select ss=new Select(we);
		ss.selectByVisibleText("Programming");
		//dr.findElement(By.xpath("//input[@name='DoSearch']")).click();
	}

	@When("^click search & verify title in next page$")
	public void click_search_verify_title_in_next_page() throws Throwable {
	dr.findElement(By.xpath("//input[@name='DoSearch']")).click();
	 String title= dr.getTitle();
	 SoftAssert ss=new SoftAssert();
		ss.assertEquals(title,matchtile);
		ss.assertAll();
	   System.out.println(title);
	}

	@Then("^verify the name of second book$")
	public void verify_the_name_of_second_book() throws Throwable {
		String name2=dr.findElement(By.xpath("/html/body/table[5]/tbody/tr/td/table[2]/tbody/tr[3]/td[2]/b/a")).getText();
		
		SoftAssert ss=new SoftAssert();
		ss.assertEquals(name2,name2match);
		ss.assertAll();
		System.out.println(name2);
	}
	


}
